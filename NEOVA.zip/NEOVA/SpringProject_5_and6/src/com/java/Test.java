package com.java;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("SpringConfig2.xml");
		Car theCar = (Car) container.getBean("mycar");
		theCar.startCar();
		System.out.println("-----------------------------");
		
		Department theDept = (Department) container.getBean("mydept");
		
		
		//theDept.setDepartmentNumber(5);
		//theDept.setDepartmentName("swapnil");
	//	theDept.setDepartmentLoaction("Nagpur");
		
		System.out.println("Dept no : "+theDept.getDepartmentNumber());
		System.out.println("Dept Name : "+theDept.getDepartmentName());
		System.out.println("Dept location : "+ theDept.getDepartmentLoaction());
		System.out.println("------------------------------------");
		
		
		Shop theShop = (Shop) container.getBean("myshop");
		
         // theShop.setShopNumber(10);
		 // theShop.setShopName("dssd");
		  //theShop.setShopAddress("fsfs");
		  
		System.out.println("Shop no : "+theShop.getShopNumber());
		System.out.println("Dept Name : "+theShop.getShopName());
		//System.out.println("Dept location : "+ theShop.getShopAddress());
		System.out.println("------------------------------------");
		
		
		/*theDept.setDepartmentNumber(10);
		theDept.setDepartmentName("swapnil");
		theDept.setDepartmentLoaction("Nagpur");
		
		System.out.println("Dept no : "+theDept.getDepartmentNumber());
		System.out.println("Dept Name : "+theDept.getDepartmentName());
		System.out.println("Dept location : "+ theDept.getDepartmentLoaction());
		System.out.println("------------------------------------");
		
	
		Employee theEmp = (Employee) container.getBean("myemp");
		
		theEmp.setEmployeeNo(1);
		theEmp.setEmployeeName("Swapnil");
		theEmp.setEmployeeAddress("vaishali Nagar Mouda");
		
		System.out.println("Emp number : "+theEmp.getEmployeeNo());
		System.out.println("Emp Name : "+theEmp.getEmployeeName());
		System.out.println("Emp address : "+ theEmp.getEmployeeAddress());
		*/
		
	}
}
