package com.java;

public class Shop {
	
	private int ShopNumber;
	private String ShopName;
	
	
	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public int getShopNumber() {
		return ShopNumber;
	}
	public void setShopNumber(int shopNumber) {
		ShopNumber = shopNumber;
	}
	public String getShopName() {
		return ShopName;
	}
	public void setShopName(String shopName) {
		ShopName = shopName;
	}

}
