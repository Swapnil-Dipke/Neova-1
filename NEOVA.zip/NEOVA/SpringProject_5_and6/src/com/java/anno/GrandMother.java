package com.java.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mygrandmother")
@Scope("prototype")
public class GrandMother {

	public GrandMother() {
	   
		System.out.println("Grandmother()..");
		
	}

	void GrandMother1() {
        System.out.println("grand mother having stories to tell...");		
	}
	
}
