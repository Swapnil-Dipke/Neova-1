package com.java.anno;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test2 {

public static void main(String[] args) {
	
	System.out.println("continer loading..");
	ApplicationContext container = new ClassPathXmlApplicationContext("SpringAnnoConfig.xml");
	
	 System.out.println("constructoris loaded ...");
	 
	 
	//GrandMother theGrandMother =container.getBean("mygrandmother", GrandMother.class);
	//theGrandMother.GrandMother1();
	

	Mother theMother =container.getBean("mymother", Mother.class);
	theMother.Mother1();
	
	 
	//Daughter theDaughter =container.getBean("mydaughter", Daughter.class);
	//theDaughter.Daughter1();
	

	
	System.out.println("-----");
	//System.out.println(" ctr is loading ...");
	
}
	
}
