package com.java;

public class Department {

	private int DepartmentNumber;
	private String DepartmentName;	
	private String DepartmentLoaction;
	
	
	public int getDepartmentNumber() {
		return DepartmentNumber;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setDepartmentNumber(int departmentNumber) {
		DepartmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return DepartmentName;
	}
	public void setDepartmentName(String departmentName) {
		DepartmentName = departmentName;
	}
	public String getDepartmentLoaction() {
		return DepartmentLoaction;
	}
	public void setDepartmentLoaction(String departmentLoaction) {
		DepartmentLoaction = departmentLoaction;
	}
	
	
	
	
	
	
}
	
	
	

