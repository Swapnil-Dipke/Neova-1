package com.java.anno3;

public class Parent {
	
	public Parent() {
		// TODO Auto-generated constructor stub
	}

}
