package com.java.anno3;

public class Son extends Mother {
	
	
	

	public Son() {
		
		System.out.println("Daughter()..");
	}
	
	void Son1() {
		System.out.println(" daughter is blessings..");
	}

}
