package com.java.anno3;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mymother")
@Scope("prototype")
public class Mother{
   
	public Mother() {
		
		System.out.println("Mother()...");
	}
	public void Mother1()
	{
		System.out.println("maa ki mamtaa..");
	}
	
}
