package com.java.anno3;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test3 {
	
	@Autowired

public static void main(String[] args) {
	
	System.out.println("continer loading..");
	ApplicationContext container = new ClassPathXmlApplicationContext("SpringAnno3Config.xml");
	
	 System.out.println("constructoris loaded ...");
	 
	 
	
//
	Mother theMother =container.getBean("mymother", Mother.class);
	theMother.Mother1();
//	
//	 
//	Daughter theDaughter =container.getBean("mydaughter", Daughter.class);
//	theDaughter.Daughter1();
//	

	
	System.out.println("-----");
	//System.out.println(" ctr is loading ...");
	
}
	
}





//                     grandparent
//	  
//
//
//

