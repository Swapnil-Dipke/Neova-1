package com.java.anno3;


import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mydaughter")
@Scope("prototype")
public class Daughter extends Mother {

	
	public Daughter() {
		
		System.out.println("Daughter()..");
	}
	
	void Daughter1() {
		System.out.println(" daughter is blessings..");
	}
}
