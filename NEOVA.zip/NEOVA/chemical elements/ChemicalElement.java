public class  ChemicalElement implements Comparable<ChemicaElement>
{


	private int atomicNumber;
	private String atomicName;
	private String atomicFormula;
	private double atomicWeight;



   // @override
//		public int compareTo(ChemicalElements o)
//	{
//		System.out.println("comparing"+atomicNumber+ "with"+o.atomicNumber);
//		return Integer.compareTo(atomicNumber,o.atomicNumber);
	}




	public ChemicalElement(int atomicNumber, String atomicName, String atomicFormula, double atomicWeight)
	{
       super();
	   this.atomicNumber=atomicNumber;
	   this.atomicName=atomicName;
	   this.atomicFormula=atomicFormula;
	   this.atomicWeight=atomicWeight;
	}



@Override
	public String toString() {
		return "ChemicalElement [automicNumber=" + automicNumber + ", automicweight=" + automicweight + ", automicname="
				+ automicname + ", automicformula=" + automicformula + "]";
	}


  @override
		public int compareTo(ChemicalElements o)
	{
		System.out.println("comparing"+atomicNumber+ "with"+o.atomicNumber);
		return o.atomiFormula.compareTo(atomicFormula);
	}
	

	
}

