

public class Xraytest
{

    public static void main(String[] args)
	{
       System.out.println(" X-Ray test Begin...");

	   diagnosePart x=new diagnosePart();
	   x.setPatientName(" Amrinder Singh");
	   x.setbodyPart("crdiac area");
	   x.setgender("Male");
	   x.setPrice(45000);


       
		System.out.println("Details of patient status  : "+x);

        
		XrayMachine xray =new xray();
		x= xray.assesment(60,x);

		System.out.println("After diagnose patient status : "+x);
	}


}


//----------------------------------------------------------------

class diagnosePart
{
	private String PatientName; //aniket
	private String gender; //  M
	private String bodyPart; // brain
	private int Price; //5000
	private String assesmentStatus;// in a queue


    public String getassesmentStatus() {
		return assesmentStatus;
	}
	public void setassesmentStatus(String assesmentStatus) {
		this.assesmentStatus = assesmentStatus;
	}

    public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String Patientname) {       //setPatientName  setbodyPart  setgender
		this.PatientName = PatientName;                    // setPrice  
	}


    public String getgender() {
		return gender;
	}
	public void setgender(String gender) {
		this.gender = gender;
	}



    public String getbodyPart() {
		return bodyPart;
	}
	public void setbodyPart(String assesmentStatus) {
		this.bodyPart = bodyPart;
	}
 
    public float getPrice() {
		return Price;
	}
	public void setPrice(int Price) {
		this.Price = Price;
	}

    @Override
	public String toString() {
		return "diagnose part [Patient Name=" + PatientName + ", Body Part=" + bodyPart + ", consultant Fees=" + Price
				+ ", gender =" + gender + ", assesment status=" + assesmentStatus + "]";
	}


}

//-----------------------------------------------------------------------------------------------



class Machine
{
	
}

//-----------------------------------------------------------------
class XrayMachine extends Machine //isA
{
	
	private XrayProjector projector = new XrayProjector(); //hasA
	
	void assesment() {
		System.out.println("body assesment set for 30 minutes");
		projector.project();
	}
	
	//producesA				//usesA (int,    String)
		String assesment(int minutes, String diagnosePart) {
			System.out.println("diagnose set for "+minutes+" minutes");
			projector.project();
			return "Done Assesment "+diagnosePart;
		}
}

//--------------------------------------------------------------------------------

class Projector 
{
	void project()
	{
       System.out.println("projection....");
		projectUVRays();
	}

     
	void projectUVRays()
	{
		System.out.println("projecting UV rays...");
		collectingUVRays();
	}


	void collectingUVRays()
	{
		System.out.println("collecting UV rays...");
		createImage();
	}
	void createImage()
	{
		System.out.println("create Image as a X-ray...");
	}

}

//-------------------------------------------------------------------------
