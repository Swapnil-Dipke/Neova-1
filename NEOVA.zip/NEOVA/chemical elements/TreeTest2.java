
import java.util.*;
public class  TreeTest2
{
	public static void main(String[] args) 
	{

       // TreeSet<> myNumberSet =new TreeSet<Integer>();
		System.out.println("container is ready...");

		ChemicalElement chemicalElement1= new ChemicalElement(10,"Neon","Ne",20.180);
		ChemicalElement chemicalElement2= new ChemicalElement(15,"phosporous","P",30.974);
		ChemicalElement chemicalElement3= new ChemicalElement(8,"Oxygen","O2",20.180);
		ChemicalElement chemicalElement4= new ChemicalElement(10,"Calcium","Ca",20.180);
		ChemicalElement chemicalElement5= new ChemicalElement(10,"Boron","B",10.180);
		ChemicalElement chemicalElement6= new ChemicalElement(9,"flourine",18.990);
		ChemicalElement chemicalElement7= new ChemicalElement(13,"Aluminium","Au",26.98154);

        TreeSet<ChemicalElements> periodicTable = new TreeSet<ChemicalElements>();
		
		

		System.out.println("adding 1st element..");
        periodicTable.add(chemicalElement1);

		System.out.println("adding 2nd element..");
        periodicTable.add(chemicalElement2);

		System.out.println("adding 3rd element..");
        periodicTable.add(chemicalElement3);

		System.out.println("adding 4th element..");
        periodicTable.add(chemicalElement4);

		System.out.println("adding 5th element..");
        periodicTable.add(chemicalElement5);

		System.out.println("adding 6th element..");
        periodicTable.add(chemicalElement6);

		System.out.println("adding 7th element..");
        periodicTable.add(chemicalElement7);


		System.out.println("content s added to the periodic table ");


		Iterator<ChemicalElements> numberIterator =myNumberSet.iterator();

			while (numberIterator.hasNext())
			{
				ChemicalElement theElement=numberIterator.next();
				System.out.println("num is "+theElement);
			}
	}
}
