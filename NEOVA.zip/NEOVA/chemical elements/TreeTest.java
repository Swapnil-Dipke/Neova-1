
import java.util.*;
public class  TreeTest
{
	public static void main(String[] args) 
	{

        TreeSet<Integer> myNumberSet =new TreeSet<Integer>();
		System.out.println("container is ready...");

		System.out.println("adding first element..");
		myNumberSet.add(10);

		System.out.println("adding second element..");
        myNumberSet.add(15);

        myNumberSet.add(8);
        myNumberSet.add(5);
        myNumberSet.add(23);
        myNumberSet.add(8);
        myNumberSet.add(9);

		System.out.println("Hello World!");


		Iterator<Integer> numberIterator =myNumberSet.iterator();

			while (numberIterator.hasNext())
			{
				int num=numberIterator.next();
				System.out.println("num is "+num);
			}
	}
}
