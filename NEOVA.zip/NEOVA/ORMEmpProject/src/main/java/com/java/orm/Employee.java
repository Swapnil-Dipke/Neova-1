package com.java.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp")
public class Employee {
	
	@Id
	@Column(name="eno")
	private int employeNumber;
	
	@Column(name="ename")
	private String employeeName;
	
	@Column(name="eloc")
	private String emplpoyeeLoction;

	
	public int getEmployeNumber() {
		return employeNumber;
	}

	public void setEmployeNumber(int employeNumber) {
		this.employeNumber = employeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmplpoyeeLoction() {
		return emplpoyeeLoction;
	}

	public void setEmplpoyeeLoction(String emplpoyeeLoction) {
		this.emplpoyeeLoction = emplpoyeeLoction;
	}

}
