package com.java.orm;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmployeeTest {
	
	
	

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPAEMP");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
				Employee emp = null;
				System.out.println("null POJO created...");
	
				emp = entityManager.find(Employee.class,369);
				System.out.println("DEPTNO : "+emp.getEmployeNumber());
				System.out.println("DNAME  : "+emp.getEmployeeName());
				System.out.println("DLOC   : "+emp.getEmplpoyeeLoction());
				
				System.out.println("GOT THE POJO FROM DB..");
				System.out.println("RETRIEVED...");
				
		transaction.commit();
		System.out.println("Committed...");
		
	}
	
	
		
	}



	
	
	


