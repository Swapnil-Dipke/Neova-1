import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.orm.Employee;





public class EmployeeTest {
	
	//---------INSERT ---------  J UNIT-----------------------
	
	@Test
	public void testInsertEmp() {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPAEMP");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
		Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
		Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
		Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
				Employee emp = new Employee();
				System.out.println("POJO created...");
				
				emp.setEmployeNumber(310);
				emp.setEmployeeName("Rahul");
				emp.setEmplpoyeeLoction("NY");
			
				System.out.println("POJO filled up..");
				
				entityManager.persist(emp);
				System.out.println("Persited...");
				
		transaction.commit();
		System.out.println("Committed...");
	}
	
	
	//--------UPDATE-----------------------------------------------------------------------------
		@Test
		public void empUpdateTest() {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
			System.out.println("entity manager factory : "+entityManagerFactory);
			
			
		Assertions.assertNotNull(entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("entity manager : "+entityManager);
			
		Assertions.assertNotNull(entityManager);
			
			EntityTransaction transaction = entityManager.getTransaction();
			
		Assertions.assertNotNull(transaction);
			
			System.out.println("transaction : "+transaction);
			
			transaction.begin();
			System.out.println("Transaction started....");
			
			Employee emp = null;
			System.out.println("null POJO created...");

			emp = entityManager.find(Employee.class,371);
			
		Assertions.assertNotNull(emp);
			
			System.out.println("E NO : "+emp.getEmployeNumber());
			System.out.println("ENAME  : "+emp.getEmployeeName());
			System.out.println("E LOC   : "+emp.getEmplpoyeeLoction());
			
			emp.setEmployeeName("CODING");
			emp.setEmplpoyeeLoction("PENTAGON3");
			
			entityManager.merge(emp); // it will fire update query
			
			
			
			System.out.println("GOT THE POJO FROM DB..");
			System.out.println("RETRIEVED...");
			
			transaction.commit();
			System.out.println("Committed...");
					
			
		}
		
		
		//--------DELETE-------------------------------------------------------------------
		@Test
		public void deptDeleteTest() {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
			System.out.println("entity manager factory : "+entityManagerFactory);
			
			
		Assertions.assertNotNull(entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("entity manager : "+entityManager);
			
		Assertions.assertNotNull(entityManager);
			
			EntityTransaction transaction = entityManager.getTransaction();
			
		Assertions.assertNotNull(transaction);
			
			System.out.println("transaction : "+transaction);
			
			transaction.begin();
			System.out.println("Transaction started....");
			
			Employee emp = null;
			System.out.println("null POJO created...");

			emp = entityManager.find(Employee.class,371);
			
		Assertions.assertNotNull(emp);
			
			System.out.println("EMP NO : "+emp.getEmployeNumber());
			System.out.println(" E NAME  : "+emp.getEmployeeName());
			System.out.println("E LOC   : "+emp.getEmplpoyeeLoction());
		
			entityManager.remove(emp); // it will fire update query
			
			
			
			System.out.println("GOT THE POJO FROM DB..");
			System.out.println("RETRIEVED...");
			
			transaction.commit();
			System.out.println("Committed...");
					
			
		}
		
	
	
	

}
