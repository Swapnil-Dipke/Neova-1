package com.java.container;

class Shop{
	
}

//----------------- IS A ---------------------------------------------
class DiaryShop extends Shop{
	static  Curd purchaseCurd() {
		Curd curd = new Cow().milkACow().coagulate();
		return curd;
	}
	static ClarifiedButter purchaseGhee() {
		ClarifiedButter ghee  =new Cow().milkACow().coagulate().churn().boil();
		return ghee;
	}
}
//------------------- USES A -----------------------------------------
public class AssociationProject {

	public static void main(String[] args) {
		
		Cow theCow = new Cow();
		Milk milk = theCow.milkACow();
		milk.showMilk();
		
		Curd theCurd= milk.coagulate();
		theCurd.showCurd();
		
		Butter butter = theCurd.churn();
		butter.showButter();
		
		ClarifiedButter ghee = butter.boil();
		ghee.eat();		
	}
}

//----------------------------------------
class Cow{
	Milk  milkACow() {
		return new Milk();
	}
}
//--------------------------------------------
class Milk{
	void showMilk() {
		System.out.println("showMilk()........");
		
	}
	Curd coagulate() {
		return new Curd();
		
	}
	
}

//------  PROUCES A  --------------------------------------------------
class Curd
{
	void showCurd() {
		// TODO Auto-generated method stub
		System.out.println("showCurd() .....");
		
	}
	Butter churn() {
		Butter butter =new Butter();
		return butter;
	}
	
}

//-----------------------------------------------------------------
class Butter{
	void showButter() {
		System.out.println(" Butter");
	}
	
	ClarifiedButter boil() {
		return new ClarifiedButter();
	}
}

//-------------------------------------------------------------
class ClarifiedButter{
	
	void eat() {
		System.out.println("Eat Amul Butter.......");
	}
}
