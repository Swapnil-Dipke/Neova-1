
class MyThread extends Thread //1
{
	String msg;
	
	MyThread(String m) {
		msg = m;
	}
	
	@Override
	public void run() {
		for(int i=0;i<=20;i++) {
			System.out.println(i+" "+ msg);
		}
	}
}
public class ThreadTest_1 {
	public static void main(String[] args) {
		
		System.out.println("Begin");
		
		
		MyThread mt1 = new MyThread("Ping"); 
		MyThread mt2 = new MyThread("\tPong"); 
		MyThread mt3 = new MyThread("\t\tPang");
		MyThread mt4 = new MyThread("\t\t\tPung");		
		System.out.println("Interval");
		
		
		mt1.start();
		mt2.start(); 
		mt3.start();
		mt4.start();
		
		System.out.println("End");
		
	}
}

interface Readable				// Runnable
{
	void read();				// run();
}
class Reader implements Readable //   Thread 
{
	public void read() { //overridden		run() { }
		
	}
}
class BookReader extends Reader		// MyThread
{
	public void read() { //overriding
		
	}
}














