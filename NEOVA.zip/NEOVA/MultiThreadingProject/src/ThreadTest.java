



class MyThread extends Thread 
{
	String msg;
	
	MyThread(String m) {
		msg = m;
	}
	
	
	@Override
	public void run() {
		for(int i=0;i<=20;i++) {
			System.out.println(i+" "+ msg);
		}
	}
}

//------------- MAIN METHOD -------------------
public class ThreadTest {
	public static void main(String[] args) {
		
		System.out.println("Begin");
		
		
		MyThread mt1 = new MyThread("Ping"); 
		MyThread mt2 = new MyThread("\tPong"); 
		MyThread mt3 = new MyThread("\t\tPang"); 
		MyThread mt4 = new MyThread("\t\t\tPung"); 
		
				
		 
		mt1.start();
		mt2.start();
		mt3.start();
		mt4.start();
		
		System.out.println("End");
		
	}
}

interface Readable				// Runnable with run();
{
	void read();				
}
class Reader implements Readable //   Thread  run():
{
	public void read() { //overridden		
		
	}
}
class BookReader extends Reader		// MyThread
{
	public void read() { //overriding
		
	}
}














