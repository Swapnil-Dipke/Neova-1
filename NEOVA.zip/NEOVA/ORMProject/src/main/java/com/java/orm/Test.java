package com.java.orm;

public class Test {

	public static void main(String[] args) {
		
		EntityManagerFctory entityManagerFactory = new Persistance.createEntityManager("MyJPA");
		
	}
	
}
