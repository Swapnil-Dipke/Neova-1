public class tester 
{
	public static void main(String[] args) 
	{
		song s1=new song ();


		Myjukebox jukebox=new Myjukebox();
		jukebox.print();
		jukebox.swap();
		jukebox.print();
		
		
		System.out.println("Hello World!");
	}
}
