package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


//------------------POJO FOR TRANSACTION TABLE -----------------

@Entity
@Table(name="Transactional_Table")
public class TransactionTable {

	@Id
	@Column(name="Transaction_Id")
	private String trannsactionId;
	
	@Column(name="Transaction_Id")
	private String transactionType;
	
	@Column(name="Transaction_Mode")
	private String transactionMode;
	
	@Column(name="Transaction_Amount")
	private float transactionAmount;
	
	@Column(name="Transaction_Status")
	private String transactionStatus;

	
	//------------------- GETTER AND SETTER METHOD -----------------------
	
	
	public String getTrannsactionId() {
		return trannsactionId;
	}

	public void setTrannsactionId(String trannsactionId) {
		this.trannsactionId = trannsactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public float getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@Override
	public String toString() {
		return "TransactionTable [trannsactionId=" + trannsactionId + ", transactionType=" + transactionType
				+ ", transactionMode=" + transactionMode + ", transactionAmount=" + transactionAmount
				+ ", transactionStatus=" + transactionStatus + "]";
	}


	
	
	
	
	
	
	
	
}
