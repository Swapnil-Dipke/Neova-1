CREATE TABLE Admin_Table (
 Admin_Id VARCHAR PRIMARY KEY ,
 Admin_Password VARCHAR(20),

);


CREATE TABLE Booking_Table (
 Booking_Id VARCHAR(20) PRIMARY KEY ,
 Economy_Seats_Booked VARCHAR(14),
 

);

