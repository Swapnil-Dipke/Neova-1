package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BookingTable")
public class BookingTable
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Booking_Id")
	private String bookingId;
	
	@Column(name="Economy_Seats_Booked")
	private int economySeatsBooked;
	
	@Column(name="business_Seats_Booked")
	private int businessSeatsBooked;
	
	@Column(name="Booking_Date")
	private LocalDate bookingDate;
	
	@Column(name="Booking_Status")
	private String bookingStatus;
	
	@Column(name="Journey_Type")
	private String JourneyType;
	
	@Column(name="return_id")
	private String return_Id;
	
	@Column(name="total_Cost")
	private int totalCost;
	
	@Column(name="Transaction_ID")
	private int transactionId;
	
	@Column(name="User_Id")
	private String userId;
	
	@Column(name="Flight_Id")
	private int flightId;

	

	public String getBookingId() {
		return bookingId;
	}



	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}



	public int getEconomySeatsBooked() {
		return economySeatsBooked;
	}



	public void setEconomySeatsBooked(int economySeatsBooked) {
		this.economySeatsBooked = economySeatsBooked;
	}



	public int getBusinessSeatsBooked() {
		return businessSeatsBooked;
	}



	public void setBusinessSeatsBooked(int businessSeatsBooked) {
		this.businessSeatsBooked = businessSeatsBooked;
	}



	public LocalDate getBookingDate() {
		return bookingDate;
	}



	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}



	public String getBookingStatus() {
		return bookingStatus;
	}



	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}



	public String getJourneyType() {
		return JourneyType;
	}



	public void setJourneyType(String journeyType) {
		JourneyType = journeyType;
	}



	public String getReturn_Id() {
		return return_Id;
	}



	public void setReturn_Id(String return_Id) {
		this.return_Id = return_Id;
	}



	public int getTotalCost() {
		return totalCost;
	}



	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}



	public int getTransactionId() {
		return transactionId;
	}



	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public int getFlightId() {
		return flightId;
	}



	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}



	@Override
	public String toString() {
		return "BookingTable [bookingId=" + bookingId + ", economySeatsBooked=" + economySeatsBooked
				+ ", businessSeatsBooked=" + businessSeatsBooked + ", bookingDate=" + bookingDate + ", bookingStatus="
				+ bookingStatus + ", JourneyType=" + JourneyType + ", return_Id=" + return_Id + ", totalCost="
				+ totalCost + ", transactionId=" + transactionId + ", userId=" + userId + ", flightId=" + flightId
				+ "]";
	}
	
	
	
}
