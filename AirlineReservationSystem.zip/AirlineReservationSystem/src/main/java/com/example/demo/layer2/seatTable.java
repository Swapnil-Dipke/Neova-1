package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Seat_Table")
public class seatTable {

@Id
@Column(name="Seat_Number")
private String seatNumber;

@Column(name="Seat_Type")
private String seatType;





public String getSeatNumber() {
	return seatNumber;
}

public void setSeatNumber(String seatNumber) {
	this.seatNumber = seatNumber;
}

public String getSeatType() {
	return seatType;
}

public void setSeatType(String seatType) {
	this.seatType = seatType;
}


	
	
}
