package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Seat_Table")
public class seatTable {

@Id
@Column(name="Seat_Number")
private String seatNumber;



@Column(name="Seat_Type")
private String seatType;
 
@ManyToOne
	@JoinColumn(name="Passenger_Ticket_Book") // FK for emp table
	private PassengerTicketBook passengerTicketBook;
	



public String getSeatNumber() {
	return seatNumber;
}

public void setSeatNumber(String seatNumber) {
	this.seatNumber = seatNumber;
}

public String getSeatType() {
	return seatType;
}

public void setSeatType(String seatType) {
	this.seatType = seatType;
}



public PassengerTicketBook getPassengerTicketBook() {
	return passengerTicketBook;
}

public void setPassengerTicketBook(PassengerTicketBook passengerTicketBook) {
	this.passengerTicketBook = passengerTicketBook;
}

@Override
public String toString() {
	return "seatTable [seatNumber=" + seatNumber + ", seatType=" + seatType + ", passengerTicketBook="
			+ passengerTicketBook + "]";
}








	
	
}
