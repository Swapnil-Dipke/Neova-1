package com.example.demo.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Passenger_Ticket_Book")
public class PassengerTicketBook 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Passenger_Transaction_ID")
	private String passengerTransactionId;
	
	@Column(name="Passenger_ID")
	private String passengerId;
	
	@Column(name="Booking_ID")
	private String BookingId;

	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "Seat_Table") //one Department has Many Employees
		private Set<seatTable> seatTableSet = new HashSet<seatTable>();
		
		
	
	
	@ManyToOne
	@JoinColumn(name="Flight_ID")
	private String flightId;

	
	
	//--------- GETTER AND SETTER METHOD --------------------
	
	public String getPassengerTransactionId() {
		return passengerTransactionId;
	}



	public void setPassengerTransactionId(String passengerTransactionId) {
		this.passengerTransactionId = passengerTransactionId;
	}
	
	

	public String getPassengerId() {
		return passengerId;
	}



	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}



	public String getBookingId() {
		return BookingId;
	}



	public void setBookingId(String bookingId) {
		BookingId = bookingId;
	}


/*
	public int getSeatNo() {
		return seatNo;
	}



	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

*/

	public String getFlightId() {
		return flightId;
	}



	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}



	@Override
	public String toString() {
		return "PassengerTicketBook [passengerId=" + passengerId + ", BookingId=" + BookingId +  ", flightId=" + flightId + "]";
	}
	
	
	
	
	
	
}
