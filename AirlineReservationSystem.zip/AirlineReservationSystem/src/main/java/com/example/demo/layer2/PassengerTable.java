package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


//----------- POJO FOR PASSENGER TABLE ---------------

@Entity
@Table(name="Passenger_Table")
public class PassengerTable {
	
	@Id
	@Column (name="Passenger_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String passengerId;
	
	@Column(name="First_Name")
	private String firstName;
	
	@Column(name="Last_Name")
	private String lastName;
	
	@Column(name="Gender")
	private char gender;
	
	@Column(name="User_Id")
	private String userId;

	
	//----------------------- GETTER AND SETTER METHOD ------------------
	
	public String getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	
	//------------------ to string()  ------------

	
	@Override
	public String toString() {
		return "PassengerTable [passengerId=" + passengerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", userId=" + userId + "]";
	}

	

}
