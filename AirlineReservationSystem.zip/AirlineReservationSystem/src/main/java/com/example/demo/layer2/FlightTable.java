package com.example.demo.layer2;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


//-------------------------- POJO flgiht table-------------------
@Entity
@Table(name="flighttable")
public class FlightTable {
     
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="flightid")
	private int FlightId;
	
	@Column(name="flightname")
	private String FlightName;
	
	@Column(name="destinationlocation")
	private String DestinationLocation;
	
	@Column(name="departuretime")
	private LocalDateTime DepartureTime;
    
	@Column(name="arrivaldatetime")
	private LocalDateTime ArrivalDateTime;
	
	@Column(name="economyclassprice")
	private float EconomyClassPrice;
	
	@Column(name="buissnessclassprice")
	private float BuissnessClassPrice;
	
	@Column(name="totaleconomyseats")
	private int TotalEconomySeats;
	
	@Column(name="totalbuissnessseats")
	private int TotalBUissnessSeats;
	
	@Column(name="availableeconomyseats")
	private int AvailableEconomySeats;
	
	@Column(name="availablebuissnessseats")
	private int AvailableBuissnessSeats;
	

	//------------- GETTER AND SETTER METHOD --------------------------
	


	public int getFlightId() {
		return FlightId;
	}

	public void setFlightId(int flightId) {
		FlightId = flightId;
	}

	public String getFlightName() {
		return FlightName;
	}

	public void setFlightName(String flightName) {
		FlightName = flightName;
	}

	public String getDestinationLocation() {
		return DestinationLocation;
	}

	public void setDestinationLocation(String destinationLocation) {
		DestinationLocation = destinationLocation;
	}

	public LocalDateTime getDepartureTime() {
		return DepartureTime;
	}

	public void setDepartureTime(LocalDateTime departureTime) {
		DepartureTime = departureTime;
	}

	public LocalDateTime getArrivalDateTime() {
		return ArrivalDateTime;
	}

	public void setArrivalDateTime(LocalDateTime arrivalDateTime) {
		ArrivalDateTime = arrivalDateTime;
	}

	public float getEconomyClassPrice() {
		return EconomyClassPrice;
	}

	public void setEconomyClassPrice(float economyClassPrice) {
		EconomyClassPrice = economyClassPrice;
	}

	public float getBuissnessClassPrice() {
		return BuissnessClassPrice;
	}

	public void setBuissnessClassPrice(float buissnessClassPrice) {
		BuissnessClassPrice = buissnessClassPrice;
	}

	public int getTotalEconomySeats() {
		return TotalEconomySeats;
	}

	public void setTotalEconomySeats(int totalEconomySeats) {
		TotalEconomySeats = totalEconomySeats;
	}

	public int getTotalBUissnessSeats() {
		return TotalBUissnessSeats;
	}

	public void setTotalBUissnessSeats(int totalBUissnessSeats) {
		TotalBUissnessSeats = totalBUissnessSeats;
	}

	public int getAvailableEconomySeats() {
		return AvailableEconomySeats;
	}

	public void setAvailableEconomySeats(int availableEconomySeats) {
		AvailableEconomySeats = availableEconomySeats;
	}

	public int getAvailableBuissnessSeats() {
		return AvailableBuissnessSeats;
	}

	public void setAvailableBuissnessSeats(int availableBuissnessSeats) {
		AvailableBuissnessSeats = availableBuissnessSeats;
	}

		
	
	
	
}
